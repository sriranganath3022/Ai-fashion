export type themeType =
  | "Top Wear"
  | "Bottom Wear";

export const themes: themeType[] = [
  "Top Wear",
  "Bottom Wear"
];
